#!/usr/bin/env python3
"""E4 CCPD-GT benchmark logic tests — loader / stats / Layer-1 reflection.

Pure logic only (no OCR, no images): the GT loader is checked against the
real labels.txt (fast, 98,459 lines), accuracy statistics and the
deterministic confusion-pair reflection are exercised on fabricated
(pred, true) pairs. Run: ``python3 test_ccpd_gt.py``.
"""
from __future__ import annotations
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_FUSION = os.path.dirname(_HERE)
for p in (_HERE, _FUSION):
    if p not in sys.path:
        sys.path.insert(0, p)

import run_ccpd_gt as CG

_passed = _failed = 0


def check(name, cond, detail=""):
    global _passed, _failed
    if cond:
        _passed += 1
        print(f"  PASS  {name}")
    else:
        _failed += 1
        print(f"  FAIL  {name}  {detail}")


def test_loader():
    print("[GT loader: labels.txt consistency]")
    rows = CG.load_labels()
    check("98,459 rows loaded", len(rows) == 98459, len(rows))
    check("every row has file + plate",
          all(r["file"].startswith("data/") and r["plate"] for r in rows))
    check("plates are alnum (normalized)",
          all(r["plate"].isalnum() and r["plate"].isupper() for r in rows[:500]))
    subs = {}
    for r in rows:
        subs[r["subset"]] = subs.get(r["subset"], 0) + 1
    check("all 7 difficulty subsets present",
          set(CG.SUBSETS) <= set(subs), subs)
    check("subset counts sum to total", sum(subs.values()) == 98459, subs)
    # filename label consistency is structural: labels.txt column 2 == filename
    # prefix before the first '_' (the CCPD-GT guarantee)
    sample = rows[:200]
    check("filename prefix == label (spot check)",
          all(r["plate"] == CG.normalize(
              os.path.basename(r["file"]).split("_")[0]) for r in sample),
          [r["file"] for r in sample[:3] if r["plate"] != CG.normalize(
              os.path.basename(r["file"]).split("_")[0])])


def test_classify_and_stats():
    print("[classify + accuracy stats (pure math)]")
    rows = [
        {"plate": "Q1G728", "ocr": "Q1G728", "subset": "base"},        # exact
        {"plate": "Q1G728", "ocr": "O1G728", "subset": "base"},        # tolerant
        {"plate": "Q1G728", "ocr": "X9Z111", "subset": "base"},        # miss
        {"plate": "ABM029", "ocr": "ABM029", "subset": "blur"},        # exact
    ]
    for r in rows:
        exact, tolerant = CG.classify_row(r["plate"], r["ocr"],
                                          CG.DEFAULT_TABLE)
        r["exact"], r["tolerant"] = exact, tolerant
    st = CG.accuracy_stats(rows)
    overall = st["overall"]
    check("overall exact 2/4", overall["exact_acc"] == 0.5, overall)
    check("overall tolerant 3/4", overall["tolerant_acc"] == 0.75, overall)
    check("false_equal = tolerant-not-exact (1/4)",
          overall["false_equal_rate"] == 0.25, overall)
    check("per-subset stats present", "base" in st and "blur" in st, list(st))


def test_reflect_confusables():
    print("[deterministic confusion-pair reflection]")
    rows = [
        {"plate": "Q1G728", "ocr": "O1G728"},   # Q<->O x3
        {"plate": "Q1G728", "ocr": "O1G728"},
        {"plate": "Q1G728", "ocr": "O1G728"},
        {"plate": "Q1G728", "ocr": "Q1G72B"},   # 8<->B x1 (below support)
        {"plate": "ABM029", "ocr": "ABM029"},
    ]
    table = CG.reflect_confusables(rows, base_table={"Q": "9"}, min_support=2)
    check("Q gains O (3 occurrences)", "O" in table["Q"], table)
    check("O gains Q (symmetric)", "Q" in table.get("O", ""), table.get("O"))
    check("existing Q->9 preserved", "9" in table["Q"], table["Q"])
    check("below-support pair NOT added", "B" not in table.get("8", ""),
          table.get("8", ""))
    check("unchanged pairs add nothing", table.get("A", "") == ""
          and table.get("M", "") == "", table)


def test_tolerant_metrics():
    print("[tolerant_metrics on the engine matching rule]")
    rows = [
        {"plate": "Q1G728", "ocr": "Q1G728", "tolerant": True},
        {"plate": "Q1G728", "ocr": "11G728", "tolerant": True},
        {"plate": "Q1G728", "ocr": "ZZZZZZ", "tolerant": False},
    ]
    m = CG.tolerant_metrics(rows, CG.DEFAULT_TABLE)
    check("tolerant_acc 2/3", m["tolerant_acc"] == round(2 / 3, 4), m)
    check("n reported", m["n"] == 3, m)


if __name__ == "__main__":
    test_loader()
    test_classify_and_stats()
    test_reflect_confusables()
    test_tolerant_metrics()
    print(f"\n{'='*48}\n{_passed} passed, {_failed} failed")
    sys.exit(1 if _failed else 0)
